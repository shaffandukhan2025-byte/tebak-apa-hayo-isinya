WEBSITE MINTA MAAF UNTUK PAVITA 💗

Isi:
- index.html: seluruh website, termasuk HTML, CSS, dan JavaScript dalam satu file.
- Desain responsif untuk iPhone dan desktop.
- 10 tampilan dengan tombol navigasi.
- Gerbang password lucu (pavita / pavita123 / ziadatu / sayang).
- Surat rahasia, tebak-tebakan, unggah foto lokal, musik latar orisinal dengan Web Audio, respons akhir berbeda, dan animasi hati.

CARA MEMBUKA:
1. Buka index.html di browser untuk mencoba. Beberapa browser mungkin membatasi fitur tertentu saat membuka file lokal.
2. Agar bisa dibagikan lewat tautan, unggah folder ini ke layanan hosting statis gratis.

PUBLIKASI GRATIS VIA GITHUB PAGES:
1. Login ke GitHub dan buat repository baru, misalnya `surat-untuk-pavita`.
2. Upload `index.html` ke bagian paling atas/root repository (bukan hanya ke folder lain).
3. Buka Settings → Pages.
4. Pada bagian Build and deployment, pilih `Deploy from a branch`.
5. Pilih branch `main` dan folder `/(root)`, lalu Save.
6. Tunggu beberapa menit. GitHub akan menampilkan tautan Pages di halaman Settings → Pages.
7. Buka tautan tersebut dari iPhone untuk mengetes, lalu kirim tautannya kepada penerima.

ALTERNATIF NETLIFY:
1. Buka Netlify dan login/daftar.
2. Pilih opsi untuk menambahkan/deploy situs secara manual (manual deploy / drag-and-drop).
3. Unggah folder yang berisi `index.html` atau ZIP folder ini, mengikuti instruksi terbaru di Netlify.
4. Setelah deploy selesai, gunakan URL situs yang diberikan Netlify.

CATATAN PENTING:
- Password di website ini hanya untuk efek kejutan. Karena kode website publik dapat dilihat, password tidak melindungi informasi rahasia.
- Foto yang dipilih lewat tombol “Pilih foto” hanya ditampilkan secara lokal di browser pengunjung dan tidak ikut terkirim ke penerima. Jika ingin foto tampil untuk Pavita, masukkan foto yang memang ingin dibagikan ke kode website atau gunakan URL gambar publik yang sesuai sebelum dipublikasikan.
- Musik menggunakan melodi sederhana yang dibuat langsung oleh browser; harus diaktifkan lewat tombol “Musik” karena iPhone/browser biasanya memblokir autoplay.
- Website tidak mengirim notifikasi saat dibuka atau dibaca. Fitur seperti itu memerlukan layanan tambahan.
